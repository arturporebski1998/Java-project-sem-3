package artur.porebski.model;

import java.util.Arrays;

/**
 * Class containing separate methods for each statistic operation
 * @author Artur Porębski
 * @version 1.0
 */
public class Calculations {
    
    /**
     * Method calcultaing mean value from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the mean value calculated from the array
     */
    public double mean(double[] arr) {
      /**
       * Variable storing mean value
       */
      double mean = 0;
      for(int i=0;i<arr.length;i++) {
        mean += arr[i];
      }
      mean = mean/arr.length;
      return mean;
  }
    
    /**
     * Method calcultaing median from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the median value calculated from the array
     */
    public double median(double[] arr) {
      /**
       * Variable storing median value
       */
      double median;
      /**
       * Variable storing mean value of two numbers in the middle of the data array
       */
      double mean2values;
      Arrays.sort(arr);
      
      if (arr.length % 2 == 0 ) {
          mean2values = arr[arr.length/2] + arr[(arr.length/2)-1];
          median = mean2values/2;
      }
      else {
          median = arr[arr.length/2];
      }
      return median;
  }
    
    /**
     * Method calcultaing variance from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the variance value calculated from the array
     */
    public double variance(double[] arr) {
        /**
         * Variable storing variance value
         */
        double variance = 0;
        /**
         * Array storing the values of the nominator of the variance formula
         */
        double[] var = new double[arr.length];
        for(int i=0;i<arr.length;i++) {
              var[i] = (arr[i]- mean(arr))*(arr[i]-mean(arr));
              variance += var[i];
          }
        variance = variance/arr.length;
        return variance;
    }
    
    /**
     * Method calcultaing standart deviation from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the standart deviation value calculated from the array
     */
    public double stdDev(double[] arr) {
        /**
         * Variable storing standard deviation value value
         */
        double stdDev = Math.sqrt(variance(arr));
        return stdDev;
    }
    
    /**
     * Method calcultaing geometric mean from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the geometric mean value calculated from the array
     */
    public double geometricMean(double[] arr) {
        /**
         * Variable storing geometric mean value of the data
         * Starts as a 1, because in the next iterations, value is multiplied
         */
        double geometric = 1;
        for (int i = 0; i<arr.length; i++){
          geometric *= arr[i];
        }
        geometric = Math.pow(geometric, (1.0/arr.length));
        return geometric;
    }
  
    /**
     * Method calcultaing harmonic mean from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the harmonic mean value calculated from the array
     */
    public double harmonicMean(double[] arr) {
        /**
         * Variable storing harmonic mean value of the data
         */
        double harmonic = 0;
        for (int i = 0; i<arr.length; i++){
          harmonic += 1/arr[i];
        }
        harmonic = arr.length/harmonic;
        return harmonic;
    }
    
    /**
     * Method calcultaing coefficient of variation from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the coefficient of variation value calculated from the array
     */
    public double coefOfVar(double[] arr) {
        /**
         * Variable storing coefficient of variation value of the data
         */
        double coefOfVar = stdDev(arr)/mean(arr);
        return coefOfVar;
    }
  
    /**
     * Method calcultaing minimum from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the minimum value calculated from the array
     */
    public double minimum(double[] arr) {
        Arrays.sort(arr);
        /**
         * Variable storing minimum value of the data
         */
        double min = arr[0];
        return min;
    }
    
    /**
     * Method calcultaing maximum from the data
     * @param arr Parameter to which a filled table is assigned
     * @return Returns the maximum value calculated from the array
     */
    public double maximum(double[] arr) {
        Arrays.sort(arr);
        /**
         * Variable storing maximum value of the data
         */
        double max = arr[arr.length-1];
        return max;
    }
    
    
    
}
