package artur.porebski.view;

import artur.porebski.model.Calculations;
import java.util.Scanner;

/**
 * Class containing methods controling the input and output stream
 * @author Artur Porębski
 * @version 1.0
 */
public class View {
    
    /**
     * Method, which fills the array with data entered by the user
     * @param arr Parameter to which a filled table is assigned
     */
    public void fillArray(double[] arr) {
        for(int i=0;i<arr.length;i++) {
           System.out.print("Type " + (i+1) + ". number: ");
           Scanner scan = new Scanner(System.in);
           arr[i] = scan.nextDouble();
       }
    }
    
    /**
     * Method, which display filled array
     * @param arr Parameter to which a filled table is assigned
     */
    public void displayArray(double[] arr) {
      System.out.print("\nConsidered data:\n| ");
      for(int i = 0; i < arr.length; i++) {
        System.out.print(arr[i] + " | ");
      }
    }
    
    /**
     * Method, which display calculated statistics
     * @param arr Parameter to which a filled table is assigned
     */
    public void displayStatistics(double[] arr) {
      System.out.print("\n\nStatistics of the data:\n");
      Calculations calculations = new Calculations();
      System.out.println("1. Mean value = " + calculations.mean(arr) );
      System.out.println("2. Median = " + calculations.median(arr));
      System.out.println("3. Variance = " + calculations.variance(arr));
      System.out.println("4. Standard deviation = " + calculations.stdDev(arr));
      System.out.println("5. Geometric mean = " + calculations.geometricMean(arr));
      System.out.println("6. Harmonic mean = " + calculations.harmonicMean(arr));
      System.out.println("7. Coefficient of variation = " + calculations.coefOfVar(arr));
      System.out.println("8. Minimum value = " + calculations.minimum(arr));
      System.out.println("9. Maximum value = " + calculations.maximum(arr));
    }
    
    /**
     * Method, checking if the user wants to examine the new array
     * @return Returns boolean variable 1(yes) or 0(no)
     */
    public boolean yesOrNo() {
        /**
         * Variable, taking value 1(yes) or 0(no)
         */
        boolean yesOrNo = true;
        /**
         * Variable, to which 1 or 0 is assigned
         */
        int m;
        System.out.print("\nDo you want to test new data?\nType 1 (yes) or 0 (no): ");
        Scanner scanner = new Scanner(System.in);
        m = scanner.nextInt();
        
        if (m == 1) {
            yesOrNo = true;
        }
        else if (m == 0) {
            yesOrNo = false;
        }
        
        while (m != 1 && m != 0) {
            System.out.print("Type proper number 1 (yes) or 0 (no): ");
            m = scanner.nextInt();
            if (m == 1) {
                yesOrNo = true;
            }
            else if (m == 0) {
                yesOrNo = false;
            }
        }
       
    return yesOrNo;
    }
    
    
    
}
