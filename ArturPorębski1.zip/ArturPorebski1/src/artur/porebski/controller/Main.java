package artur.porebski.controller;

import artur.porebski.model.Calculations;
import artur.porebski.view.View;
import java.util.Scanner;

/**
 * Main class of the application
 *
 * @author Artur Porębski
 * @version 1.0
 */
public class Main {

    /**
     * Main method of the application
     *
     * @param args command line parameters
     */
    public static void main(String[] args) {
        /**
         * Variable storing the size of the array entered by the user
         */
        int size = 0;
        //boolean mleko = true;
        /**
         * An array storing the data entered by the user
         */
        double[] myArray;
        System.out.print("Type the size of an array: ");

        while (size <= 0) {
            Scanner scanner = new Scanner(System.in);
            size = scanner.nextInt();
            if (size <= 0) {
                System.out.print("Array size must be greater than 0!\nTry again: ");
            }
        }
        
        View view = new View();
        Calculations calculations = new Calculations();
        
        myArray = new double[size];
        view.fillArray(myArray); 
        view.displayArray(myArray);
        view.displayStatistics(myArray); 

        while (view.yesOrNo()) {
            System.out.println("\n-----------------------------------");
            System.out.print("\nType the size of new array: ");
            
            Scanner scanner = new Scanner(System.in);
            size = scanner.nextInt();
            
            while (size <= 0) {
                System.out.print("Array size must be greater than 0!\nTry again: ");
                size = scanner.nextInt();
            }
            
            if (size > 0) {
                myArray = new double[size];
                view.fillArray(myArray);
                view.displayArray(myArray);
                view.displayStatistics(myArray); 
            }
            
        }
        System.out.print("You can turn off the console window.\n");

    }
}
